package com.ligool.plugin;

import com.unity3d.player.UnityPlayerActivity;

import android.content.Intent;

public class MainActivity  extends UnityPlayerActivity{
	private static MainActivity instance;
	public void shareText(String subject, String body) {
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, subject);
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

	public MainActivity(){
		this.instance = this;
	}
	
	public static MainActivity instance(){
		if(instance == null){
			instance = new MainActivity();
		}
		return instance;
	}
}
