package com.ligool.plugin;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import android.util.Log;

public class Main extends UnityPlayerActivity{
	
	private static Main instance;
	
	public Main(){
		this.instance = this;
	}
	
	public static Main instance(){
		if(instance == null){
			instance = new Main();
		}
		return instance;
	}
	
	public static void Test(){
		Log.d("Unity", "Hi, im on MainPlugin");
		callUnity();
	}
	
	private static void callUnity(){
		UnityPlayer.UnitySendMessage("_GameManager", "HelloFromAndroid", "Hi, this is a response from the plugin");
	}
	public static int getInt(){
		return 1114;
	}
}
